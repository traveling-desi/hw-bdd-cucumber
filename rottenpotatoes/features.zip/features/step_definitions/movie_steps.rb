# Add a declarative step here for populating the DB with movies.

Given /the following movies exist/ do |movies_table|
  movies_table.hashes.each do |movie|
    # each returned element will be a hash whose key is the table header.
    # you should arrange to add that movie to the database here.

       Movie.create(:title =>movie['title'], :rating =>movie['rating'],  :release_date =>movie['release_date'])
  end
end

# Make sure that one string (regexp) occurs before or after another one
#   on the same page

When /^(?:|I )follow "([^"]*)"$/ do |link|
  click_link(link)
end


Then /I should see "(.*)" before "(.*)"/ do |e1, e2|
  #  ensure that that e1 occurs before e2.
  #  page.body is the entire content of the page as a string.

  e3_match  = page.body[/#{e1}(.*?)#{e2}/m, 1]
 
  if not e3_match.nil?
	page.should have_content(e1)
  else
	page.should have_no_content(e1)
  end
  if  (/#{e1}(.*?)#{e2}/m =~ page.body)
	puts "Yup I am still  right"
  end
end

# Make it easier to express checking or unchecking several boxes at once
#  "When I uncheck the following ratings: PG, G, R"
#  "When I check the following ratings: G"


Given /^(?:|I )am on (.+)$/ do |page_name|
  visit path_to(page_name)
end

When /I (un)?check the following ratings: (.*)/ do |uncheck, rating_list|
  # HINT: use String#split to split up the rating_list, then
  #   iterate over the ratings and reuse the "When I check..." or
  #   "When I uncheck..." steps in lines 89-95 of web_steps.rb
  rArray = rating_list.split(/,/)
  if not uncheck
	rArray.each do |field|
		check("ratings_#{field.strip}")
	end
  else
	 rArray.each do |field|
		uncheck("ratings_#{field.strip}")
        end 
  end
end

When /^(?:|I )press "([^"]*)"$/ do |button|
  click_button("ratings_#{button.strip}")
end

Then /^(?:|I )should see "([^"]*)"$/ do |text|
  		if page.respond_to? :should
    			page.should have_content(text)
  		else
    			assert page.has_content?(text)
  		end
	end


## Then /^(?:|I )should see/ do |movies_table|
##   	movies_table.hashes.each do |movie|
## 		text = "| #{movie['title']} | #{movie['rating']} | #{movie['release_date']} |"
##   		if page.respond_to? :should
##     			page.should have_content(text)
##   		else
##     			assert page.has_content?(text)
##   		end
## 	end
## end
		
Then /^(?:|I )should not see "([^"]*)"$/ do |text|
  		if page.respond_to? :should
    			page.should have_no_content(text)
  		else
    			assert page.has_no_content?(text)
  		end
	end

Then /I should see all the movies/ do
  # Make sure that all the movies in the app are visible in the table
  #puts page.body
  page.all('table#movies tr').count.should == Movie.count + 1
  #fail "Unimplemented"
end
